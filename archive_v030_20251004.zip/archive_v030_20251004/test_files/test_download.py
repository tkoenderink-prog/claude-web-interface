#!/opt/homebrew/opt/python@3.11/bin/python3.11
"""Test the download functionality for conversations"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import app, db
from models.models import User, Conversation, Message
from services.download_service import get_download_service
from datetime import datetime

def test_download_service():
    """Test the download service with a sample conversation"""

    with app.app_context():
        # Get or create test user
        user = User.query.filter_by(username='default').first()
        if not user:
            print("No default user found. Please run the app first to create users.")
            return

        # Get first conversation or create a test one
        conversation = Conversation.query.filter_by(user_id=user.id).first()

        if not conversation:
            print("Creating test conversation...")
            conversation = Conversation(
                title="Test Download Conversation",
                user_id=user.id,
                model="claude-3-5-sonnet-20241022"
            )
            db.session.add(conversation)
            db.session.flush()

            # Add some messages
            messages = [
                Message(
                    conversation_id=conversation.id,
                    role="user",
                    content="Hello, can you explain what markdown is?"
                ),
                Message(
                    conversation_id=conversation.id,
                    role="assistant",
                    content="""Markdown is a lightweight markup language that you can use to format plain text documents. Here's what you need to know:

## What is Markdown?

Markdown allows you to write using an easy-to-read, easy-to-write plain text format, which then converts to structurally valid HTML.

## Basic Syntax

### Headers
- Use `#` for H1, `##` for H2, etc.

### Text Formatting
- **Bold**: Use `**text**` or `__text__`
- *Italic*: Use `*text*` or `_text_`
- `Code`: Use backticks

### Lists
1. Numbered lists with numbers
2. Like this

- Bullet lists with dashes
- Or asterisks

### Code Blocks
```python
def hello():
    print("Hello, World!")
```

### Links and Images
- Links: `[text](url)`
- Images: `![alt text](url)`

Markdown is widely used for README files, documentation, and note-taking applications like Obsidian!"""
                ),
                Message(
                    conversation_id=conversation.id,
                    role="user",
                    content="That's helpful! Can you show me an example of a table in markdown?"
                ),
                Message(
                    conversation_id=conversation.id,
                    role="assistant",
                    content="""Of course! Here's how to create tables in Markdown:

## Markdown Tables

| Column 1 | Column 2 | Column 3 |
|----------|----------|----------|
| Data 1   | Data 2   | Data 3   |
| Data 4   | Data 5   | Data 6   |
| Data 7   | Data 8   | Data 9   |

You can also align columns:

| Left Aligned | Center Aligned | Right Aligned |
|:------------|:-------------:|-------------:|
| Left        | Center        | Right        |
| Text        | Text          | Text         |

The colons (`:`) determine alignment:
- `:---` = Left aligned
- `:---:` = Center aligned
- `---:` = Right aligned"""
                )
            ]

            for msg in messages:
                db.session.add(msg)

            db.session.commit()
            print(f"Created test conversation with ID: {conversation.id}")

        print(f"\nTesting download for conversation: {conversation.title}")
        print(f"Conversation ID: {conversation.id}")

        # Get the download service
        download_service = get_download_service()

        # Test JSON export
        print("\n1. Testing JSON export...")
        try:
            result = download_service.export_conversation(conversation.id, 'json')
            print(f"   ✅ JSON export successful")
            print(f"   Filename: {result['filename']}")
            print(f"   Content length: {len(result['content'])} chars")
        except Exception as e:
            print(f"   ❌ JSON export failed: {e}")

        # Test Markdown export
        print("\n2. Testing Markdown export...")
        try:
            result = download_service.export_conversation(conversation.id, 'markdown')
            print(f"   ✅ Markdown export successful")
            print(f"   Filename: {result['filename']}")
            print(f"   Content preview (first 500 chars):")
            print("   " + "-" * 50)
            print(result['content'][:500])
            print("   " + "-" * 50)
        except Exception as e:
            print(f"   ❌ Markdown export failed: {e}")

        # Test PDF export
        print("\n3. Testing PDF export...")
        try:
            result = download_service.export_conversation(conversation.id, 'pdf')
            if result.get('error'):
                print(f"   ⚠️  PDF export not available: {result['error']}")
                print(f"   Missing libraries: {', '.join(result.get('missing_libraries', []))}")
            else:
                print(f"   ✅ PDF export successful")
                print(f"   Filename: {result['filename']}")
                print(f"   Base64 encoded: {result.get('is_base64', False)}")
        except Exception as e:
            print(f"   ❌ PDF export failed: {e}")

        # Count messages
        message_count = Message.query.filter_by(conversation_id=conversation.id).count()
        print(f"\n4. Message count verification:")
        print(f"   Total messages in conversation: {message_count}")

        print("\n✅ Download service test complete!")

if __name__ == "__main__":
    test_download_service()